'use strict';
//JSがうまく動いているかテスト
console.log('hello!');

//要素を取得する変数
//const使う
//変数「password_box」にid='password_box'のHTML要素を取得させる
const password_box=document.getElementById('password_box');

//変数「btn」にid='btn'のHTML要素を取得させる
const btn=document.getElementById('btn');

//btnがクリックされた時に発動させる
btn.onclick=function make_password(){
  //動くか確認
  console.log('OK');

  /*生成したパスワードを格納する配列とパスワードを生成するためのアルファベットを用意する配列を作る*/

  var password=[];
  var abc=[];

  //firstには"a",lastには"z"を代入
  //これをいじってパスワードを作る
  var first="a",last="z";

  //firstの"a"とlastの"z"を数字に変換「charCodeAt(0)」
  //for文で繰り返して配列に全アルファベットを格納
  for(let i=first.charCodeAt(0);i<=last.charCodeAt(0);i++){
    //「i」の数字をアルファベットに戻して配列「abc」に1つずつアルファベットを入れていく
    abc.push(String.fromCharCode(i));
    
    //増えてるか確認しよう
    console.log("i="+String.fromCharCode(i));
    console.log("abc=["+abc+"]");
  }

  console.log("アルファベット全部そろった\n abc=["+abc+"]");

  //これから生成したアルファベットの配列から乱数を使ってランダムにパスワードを取っていく
  //for文を10回繰り返して10桁のパスワードを生成
  for(let i=0; i<10;i++){
    //これ乱数
    var key=Math.floor(Math.random()* abc.length);       

    // console.log(i);
    password.push(abc[key]);
    
    console.log(abc[key]);
    console.log(password);
  }

  //配列だから[a,b,c,.....]になってるのを文字列に直す
  password=password.join(',');
  //a,b,c,.....になってるので「,」を全て取り除く
  password=password.replace( /,/g , "" ) ;

  //パスワード完成
  console.log(password);

  //password_boxのpasswordを代入
  password_box.value=password;

}